import json

def lambda_handler(event, context):
    START = event.get('START_FDCID')
    END = event.get('END_FDCID')
    inc = event.get('inc')

    assert START < END
    
    start_indexes = list(range(START, END, inc))
    tups = list(map(lambda x: {'START_FDCID':x, 'END_FDCID':x+inc}, start_indexes))

    if tups[-1].get('END_FDCID') > END:
        last_tup = tups.pop()
        last_tup['END_FDCID'] = END
        tups.append(last_tup)

    return {'fdcid_pairs': tups}
