import requests
import json
import csv
import boto3
import os

def get_nutrients(f, writer, food):
    nutrients_info = food.get('foodNutrients',[{}]) #Needs to not throw an error in the following for-loop if no foodNutrients so use []
    for nutrient_info in nutrients_info:
        row = {}
    
        # First get outer level key-vals
        row.update({'fdcId':food.get('fdcId')})
        
        # Then second level nested
        row.update({'amount':nutrient_info.get('amount')})
        
        # Then third level nested
        row.update({'nutrient_id':nutrient_info.get('nutrient',{}).get('id'), \
                    'nutrient_number':nutrient_info.get('nutrient',{}).get('number'), \
                    'name':nutrient_info.get('nutrient',{}).get('name'), \
                    'unitName':nutrient_info.get('nutrient',{}).get('unitName')
                   })
                   
        writer.writerow(row)
        
def get_foodinfo(f, writer, food):
    row = {}
    
    # First get outer level key-vals
    row.update({'fdcId':food.get('fdcId'), \
                'description':food.get('description'), \
                'publicationDate':food.get('publicationDate'), \
                'brandOwner':food.get('brandOwner'), \
                'brandedFoodCategory':food.get('brandedFoodCategory'), \
                'ingredients':food.get('ingredients'), \
                'marketCountry':food.get('marketCountry'), \
                'servingSize':food.get('servingSize'), \
                'servingSizeUnit':food.get('servingSizeUnit')              
               })
    writer.writerow(row)

def upload_file(file_name, bucket, object_name):
    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file(file_name, bucket, object_name)
    except ClientError as e:
        logging.error(e)

def lambda_handler(event, context):
    SERVER = 'https://api.nal.usda.gov/fdc'
    PATH = '/v1/foods'

    START_FDCID = event.get('START_FDCID')
    END_FDCID = event.get('END_FDCID')
    FDC_ID_RANGE = list(range(START_FDCID,END_FDCID))
    
    FOODS_FILENAME = f'FOODS_FDCID_{min(FDC_ID_RANGE)}_{max(FDC_ID_RANGE)}'
    NUTRIENTS_FILENAME = f'NUTRIENTS_FDCID_{min(FDC_ID_RANGE)}_{max(FDC_ID_RANGE)}'
    
    HEADERS = {'X-Api-Key': os.environ.get('X_api_key')}
    PARAMS = {'fdcIds': FDC_ID_RANGE}
    
    r = requests.get(f'{SERVER}{PATH}', headers=HEADERS, params=PARAMS)
    r = r.json()
    
    with open(f'/tmp/{FOODS_FILENAME}.csv', 'w', encoding='UTF8', newline='') as f:
        fieldnames = ['fdcId','description','publicationDate','brandOwner','brandedFoodCategory','ingredients','marketCountry','servingSize','servingSizeUnit']
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        for food in r:
            get_foodinfo(f, writer, food) 
            
    with open(f'/tmp/{NUTRIENTS_FILENAME}.csv', 'w', encoding='UTF8', newline='') as f:
        fieldnames = ['fdcId','name','nutrient_id','nutrient_number','amount','unitName']
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        for food in r:
            get_nutrients(f, writer, food) 
        
    upload_file(f'/tmp/{FOODS_FILENAME}.csv',os.environ.get('dest_bucket'),f'FOODS/{FOODS_FILENAME}.csv')
    upload_file(f'/tmp/{NUTRIENTS_FILENAME}.csv',os.environ.get('dest_bucket'),f'NUTRIENTS/{NUTRIENTS_FILENAME}.csv')
    
    return {'status':'SUCCESSFUL'}
